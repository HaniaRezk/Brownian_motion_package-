class Simulator:
    def __init__(self,y,mu,sigma):
        self.y=y
        self.mu=mu
        self.sigma=sigma
