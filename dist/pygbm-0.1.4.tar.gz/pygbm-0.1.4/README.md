#Pygbm
 A Python package that contains a function to simulate the Geometric Brownian motion.
 
 ##Features
Two classes: one main called Simulator and a daughter class called GMBsimulator
 
 ##Installation
 run pip install -e . from inside the package folder
 
 ##Author
 Hania Rezk
 
Author=Haniarezk
